<?php 
session_start();
include_once 'DBConnect.php';
$database = new dbConnect();

$db = $database->openConnection();
    
$id = $_SESSION['id'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashborad</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
<div class="demo-content">
    <div>
        Bem-vindo <?php echo $_SESSION["name"]; ?>
    </div>

    <div></div>
</div>
<div class="demo-content">
    <div>
        Lista de amigos:
    </div>
    <br>
    <div>
        <!-- Aqui tem código -->
    <br>
    <!-- aqui tbm -->
    </div>
</div>
<div class="demo-content">
    <div>
        Click para <a href="logout.php">SAIR</a>.
    </div>

    <div></div>
</div>
</body>
</html>